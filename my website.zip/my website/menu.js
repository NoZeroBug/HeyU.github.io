/* START MENU SCRIPT*/
document.getElementById("burger").addEventListener("click", function() {
	menu.classList.toggle("open");
});

document.querySelector("#close").addEventListener("click", () => {
	menu.classList.toggle("open");
});

document.querySelector("#menu").addEventListener("click", e => {
	e.stopPropagation();
});
/*END MENU SCRIPT*/

/*FIXED HEADER*/
$(window).scroll(function() {
	if ($(this).scrollTop() > 0){
		$('.header').addClass("sticky");
	}
	else{
		$('.header').removeClass("sticky");
	}
});
/*END FIXED HEADER*/

// typer for hello
window.onload = function() {
	var elements = document.getElementsByClassName('txt-rotate');
	for (var i = 0; i < elements.length; i++) {
		var toRotate = elements[i].getAttribute('data-rotate');
		var period = elements[i].getAttribute('data-period');
		if (toRotate) {
			new TxtRotate(elements[i], JSON.parse(toRotate), period);
		}
	}
		// INJECT CSS
		var css = document.createElement("style");
		css.type = "text/css";
		css.innerHTML = ".txt-rotate > .wrap { border-right: 10px solid #40E0D0 }";
		document.body.appendChild(css);
	};

	var TxtRotate = function(el, toRotate, period) {
		this.toRotate = toRotate;
		this.el = el;
		this.loopNum = 0;
		this.period = parseInt(period, 1) || 900;
		this.txt = '';
		this.tick();
		this.isDeleting = false;
	};

	TxtRotate.prototype.tick = function() {
		var i = this.loopNum % this.toRotate.length;
		var fullTxt = this.toRotate[i];

		if (this.isDeleting) {
			this.txt = fullTxt.substring(0, this.txt.length - 1);
		} else {
			this.txt = fullTxt.substring(0, this.txt.length + 1);
		}

		this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

		var that = this;
		var delta = 200 - Math.random() * 100;

		if (this.isDeleting) {
			delta /= 2;
		}

		if (!this.isDeleting && this.txt === fullTxt) {
			delta = this.period;
			this.isDeleting = true;
		} else if (this.isDeleting && this.txt === '') {
			this.isDeleting = false;
			this.loopNum++;
			delta = 200;
		}

		/*SLIDER*/
		setTimeout(function() {
			that.tick();
		}, delta);
	};

	$(document).ready(function() {
		
		$('.iosSlider').iosSlider({
			desktopClickDrag: true,
			snapToChildren: true,
			infiniteSlider: true,
			snapSlideCenter: true,
			navSlideSelector: '.sliderContainer .slideSelectors .item',
			navPrevSelector: '.sliderContainer .slideSelectors .prev',
			navNextSelector: '.sliderContainer .slideSelectors .next',
			onSlideComplete: slideComplete,
			onSliderLoaded: sliderLoaded,
			onSlideChange: slideChange,
			autoSlide: true,
			scrollbar: true,
			scrollbarContainer: '.sliderContainer .scrollbarContainer',
			scrollbarMargin: '0',
			scrollbarBorderRadius: '0',
			keyboardControls: true
		});
		
	});
	
	function slideChange(args) {
		
		$('.sliderContainer .slideSelectors .item').removeClass('selected');
		$('.sliderContainer .slideSelectors .item:eq(' + (args.currentSlideNumber - 1) + ')').addClass('selected');
		
	}
	
	function slideComplete(args) {
		
		if(!args.slideChanged) return false;
		
		$(args.sliderObject).find('.text1, .text2').attr('style', '');
		
		$(args.currentSlideObject).find('.text1').animate({
			left: '30px',
			opacity: '0.8'
		}, 700, 'easeOutQuint');
		
		$(args.currentSlideObject).find('.text2').delay(200).animate({
			left: '30px',
			opacity: '0.8'
		}, 600, 'easeOutQuint');
		
	}
	
	function sliderLoaded(args) {
		
		$(args.sliderObject).find('.text1, .text2').attr('style', '');
		
		$(args.currentSlideObject).find('.text1').animate({
			left: '30px',
			opacity: '0.8'
		}, 700, 'easeOutQuint');
		
		$(args.currentSlideObject).find('.text2').delay(200).animate({
			left: '30px',
			opacity: '0.8'
		}, 600, 'easeOutQuint');
		
		slideChange(args);
		
	}

/*			END OF SLIDER*/





/*DUO LAYOUT*/
var Expand = (function() {
  var tile = $('.strips__strip');
  var tileLink = $('.strips__strip > .strip__content');
  var tileText = tileLink.find('.strip__inner-text');
  var stripClose = $('.strip__close');
  
  var expanded  = false;

  var open = function() {
      
    var tile = $(this).parent();

      if (!expanded) {
        tile.addClass('strips__strip--expanded');
        // add delay to inner text
        tileText.css('transition', 'all .5s .3s cubic-bezier(0.23, 1, 0.32, 1)');
        stripClose.addClass('strip__close--show');
        stripClose.css('transition', 'all .6s 1s cubic-bezier(0.23, 1, 0.32, 1)');
        expanded = true;
      } 
    };
  
  var close = function() {
    if (expanded) {
      tile.removeClass('strips__strip--expanded');
      // remove delay from inner text
      tileText.css('transition', 'all 0.15s 0 cubic-bezier(0.23, 1, 0.32, 1)');
      stripClose.removeClass('strip__close--show');
      stripClose.css('transition', 'all 0.2s 0s cubic-bezier(0.23, 1, 0.32, 1)')
      expanded = false;
    }
  }

    var bindActions = function() {
      tileLink.on('click', open);
      stripClose.on('click', close);
    };

    var init = function() {
      bindActions();
    };

    return {
      init: init
    };

  }());

Expand.init();

/*REMOVE HOVER STRIP*/






